/*
 * Escena.cpp
 *
 *  Created on: Oct 5, 2015
 *      Author: francisco
 */

#include "escena.h"

Escena::Escena() {
	// TODO Auto-generated constructor stub
}

Escena::~Escena() {
	// TODO Auto-generated destructor stub
}


