/*
 * renderizable.cpp
 *
 *  Created on: Nov 6, 2015
 *      Author: francisco
 */

#include "renderizable.h"

Renderizable::Renderizable() {
	// TODO Auto-generated constructor stub

}

Renderizable::~Renderizable() {
	// TODO Auto-generated destructor stub
}

