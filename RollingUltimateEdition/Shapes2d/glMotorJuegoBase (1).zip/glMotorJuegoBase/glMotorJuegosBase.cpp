//============================================================================
// Name        : glMotorJuegosBase.cpp
// Author      : Francico Dominguez
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <stdio.h>
#include <string>
#include <GL/glut.h>
#include "renderizable.h"
#include "cubo.h"
#include "escena.h"
#include "esfera.h"
#include "solido.h"
#include "planoY.h"
#include "planoX.h"
#include "planoZ.h"
#include "triangulo.h"
#include "modelo.h"

GLint ancho=400;

GLint alto=400;
int hazPerspectiva = 1;
GLfloat angle = 0.0;
GLfloat yaw = 0.0;
GLfloat roll = 0.0;
GLfloat pitch = 0.0;

Escena e;

void displayMe(void)
{
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(0,3,20,0,0,0,0,1,0);
    //glTranslatef(0.0f, 0.0f, -5.0f);
    //gluLookAt (0.0, 2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
    glRotatef(yaw  ,0.0,1.0,0.0);
    glRotatef(pitch,1.0,0.0,0.0);
    glRotatef(roll ,0.0,0.0,1.0);
    GLfloat lightpos[] = {5.0, 15., 5., 0.};
    glLightfv(GL_LIGHT0, GL_POSITION, lightpos);
    e.render();
    glPushMatrix();
     glColor3f(1.0f, 1.0f, 0.0f);
     glRotatef(angle/10,0.0,1.0,0.0);
     glTranslatef(0.8,0.5,0.0);
     glutSolidCube(0.35);
      glPushMatrix();
       glColor3f(1.0f, 0.0f, 0.0f);
       glRotatef(angle/2,0.0,1.0,0.0);
       glTranslatef(0.5,0.0,0.0);
       glutSolidSphere(0.1,20,20);
      glPopMatrix();
    glPopMatrix();
    glPushMatrix();
     glColor3f(0.0f, 1.0f, 1.0f);
     glTranslatef(-0.8,0.05,-0.8);
     glutSolidSphere(0.1,10,20);
    glPopMatrix();
    glColor3f(0.0f, 1.0f, 0.0f);
    glutSolidTeapot(0.5);
    glColor3f(1.0f, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.5, 0.0, 0.0);
        glVertex3f(0.5, 0.5, 0.0);
        glVertex3f(0.0, 0.5, 0.0);
    glEnd();
//    glColor3f(1.0f, 1.0f, 1.0f);
//    glBegin(GL_POLYGON);
//        glVertex3f(-10.0, 0.0, -10.0);
//        glVertex3f( 10.0, 0.0, -10.0);
//        glVertex3f( 10.0, 0.0,  10.0);
//        glVertex3f(-10.0, 0.0,  10.0);
//    glEnd();
    glutSwapBuffers();
    angle++;
}

void init (void) {
    glEnable (GL_DEPTH_TEST);
    glEnable (GL_LIGHTING);
    glEnable (GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);
    glClearColor (0.0,0.0,0.0,0.0);
}

void reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(90.0f, (GLfloat)width/(GLfloat)height, 1.0f, 200.0f);

    glMatrixMode(GL_MODELVIEW);
    ancho = width;
    alto = height;
}
float dt=0.01;
void idle()
{
    displayMe();
    e.update(dt);
    e.resuelveColisiones();
}
void keyPressed (unsigned char key, int x, int y) {
	x++;
	y++;
	//printf("%c %d,",key,key);
    switch(key)
    {
    case 'p':
    case 'P':
      yaw++;
      break;

    case 'o':
    case 'O':
      yaw--;
      break;
    case 'q':
    case 'Q':
      pitch++;
      break;

    case 'a':
    case 'A':
      pitch--;
      break;
    case 'w':
    case 'W':
      roll++;
      break;

    case 's':
    case 'S':
      roll--;
      break;

    case 27:   // escape
      exit(0);
      break;
    }
}
int main(int argc, char** argv)
{
	Vector3D rojo(1,0,0),amarillo(1,1,0),verde(0,1,0),azul(0,0,1);

	string path(argv[1]);
	string fn0(argv[2]);
	/*
	string fn1(argv[3]);
	string fn2(argv[4]);
    */
	Modelo *m=new Modelo(path+fn0);
	m->setColor(amarillo);
	m->setP(Vector3D(0,0,0));
	m->setV(Vector3D(2.5,0,-2.5));
	e.add(m);
	/*
	m=new Modelo(*m);
	m->setColor(verde);
	m->setP(Vector3D(-1,0,0));
	e.add(m);
	m=new Modelo(path+fn1);
	m->setColor(rojo);
	m->setP(Vector3D(2,0,0));
	e.add(m);
	m=new Modelo(path+fn2);
	m->setColor(amarillo);
	m->setP(Vector3D(-2,0,0));
	e.add(m);
	*/
	Solido *c;
	c=new Cubo(Vector3D(0,0,2));
	c->setColor(rojo);
	c->setP(Vector3D(-5,0,0));
	c->setV(Vector3D(1,0,1.33));
	e.add(c);
	c=new Cubo(Vector3D(2,0,0));
	c->setV(Vector3D(1.2,0,-1.33));
	e.add(c);
	c=new Cubo(Vector3D(-2,0,0));
	c->setColor(azul);
	c->setV(Vector3D(-1,0,1.33));
	e.add(c);
	c=new Esfera(Vector3D(2,0,-2));
	c->setV(Vector3D(-1.5,0,-1.33));
	e.add(c);
	c=new Esfera(Vector3D(-2,0,-2));
	c->setV(Vector3D(-1.6,0,-1.33));
	c->setColor(verde);
	e.add(c);
	c=new PlanoY();
	e.addSolido(c);
	c=new PlanoX(-20);
	e.addLimite(c);
	c=new PlanoX(20);
	e.addLimite(c);
	c=new PlanoZ(-20);
	e.addLimite(c);
	c=new PlanoZ(20);
	e.addLimite(c);
	c=new Triangulo(Vector3D(0,0,0),Vector3D(0,1,0),Vector3D(1,0,0));
	c->setColor(rojo);
	e.addSolido(c);
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowSize(300, 300);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Teacup");
    init();
    glutDisplayFunc(displayMe);
    glutIdleFunc(idle);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyPressed); // Tell GLUT to use the method "keyPressed" for key presses
    glutMainLoop();
    return 0;
}

